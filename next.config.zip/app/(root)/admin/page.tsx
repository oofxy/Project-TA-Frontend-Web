import DashboardAdmin from "@/components/dashboard-components/DashboardAdmin";

export const dynamic = "force-dynamic";

export default function AdminPage() {
  return (
    <div>
      <DashboardAdmin />
    </div>
  );
}
